# Carrom Practice / Aim Trainer
A simple Android practice app with a carrom board, striker and interactive aim line.
It does not modify or automate any external game.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
