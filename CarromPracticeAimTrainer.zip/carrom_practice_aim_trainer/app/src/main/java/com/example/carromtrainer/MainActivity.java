package com.example.carromtrainer;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.view.*;
import android.content.*;
import android.widget.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new BoardView(this));
    }
    static class BoardView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float sx, sy, tx, ty; boolean dragging=false;
        BoardView(Context c){ super(c); p.setTypeface(Typeface.DEFAULT); setBackgroundColor(Color.rgb(17,17,17)); }
        protected void onDraw(Canvas c){
            super.onDraw(c);
            int w=getWidth(), h=getHeight();
            p.setColor(Color.WHITE); p.setTextSize(30); c.drawText("CARROM PRACTICE", 28, 45, p);
            p.setTextSize(15); p.setColor(Color.LTGRAY); c.drawText("Aim Trainer • Practice Mode", 28, 70, p);

            float size=Math.min(w-40, h-190), left=(w-size)/2f, top=105, right=left+size, bottom=top+size;
            p.setColor(Color.rgb(205,155,88)); c.drawRoundRect(left,top,right,bottom,18,18,p);
            p.setColor(Color.rgb(244,211,150)); c.drawRoundRect(left+22,top+22,right-22,bottom-22,10,10,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(Color.rgb(80,45,20));
            c.drawRect(left+50,top+50,right-50,bottom-50,p);
            p.setStyle(Paint.Style.FILL);
            float cx=w/2f, cy=top+size/2f;
            p.setColor(Color.rgb(45,45,45)); c.drawCircle(cx,cy,34,p);
            p.setColor(Color.WHITE); c.drawCircle(cx,cy,18,p);

            float strikerX = dragging ? sx : left+size*0.5f;
            float strikerY = dragging ? sy : bottom-75;
            float targetX = dragging ? tx : cx;
            float targetY = dragging ? ty : cy;
            p.setColor(Color.argb(210,0,200,83)); p.setStrokeWidth(4);
            c.drawLine(strikerX,strikerY,targetX,targetY,p);
            p.setColor(Color.WHITE); c.drawCircle(strikerX,strikerY,16,p);
            p.setColor(Color.rgb(20,20,20)); c.drawCircle(strikerX,strikerY,10,p);
            p.setColor(Color.rgb(210,40,40)); c.drawCircle(cx,cy,10,p);

            p.setColor(Color.WHITE); p.setTextSize(17);
            c.drawText("Drag from the striker to set your aim", 28, h-65, p);
            p.setColor(Color.LTGRAY); c.drawText("Practice only — no game modification", 28, h-38, p);
        }
        public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){ dragging=true; sx=e.getX(); sy=e.getY(); tx=sx; ty=sy; invalidate(); return true; }
            if(e.getAction()==MotionEvent.ACTION_MOVE){ tx=e.getX(); ty=e.getY(); invalidate(); return true; }
            if(e.getAction()==MotionEvent.ACTION_UP){ tx=e.getX(); ty=e.getY(); invalidate(); return true; }
            return true;
        }
    }
}
